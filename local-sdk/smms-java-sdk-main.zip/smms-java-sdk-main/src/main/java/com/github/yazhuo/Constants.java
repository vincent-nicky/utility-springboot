package com.github.yazhuo;

public class Constants {
    public static final String BASIC_URl = "https://sm.ms/api/v2/";

    public static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36";
}
