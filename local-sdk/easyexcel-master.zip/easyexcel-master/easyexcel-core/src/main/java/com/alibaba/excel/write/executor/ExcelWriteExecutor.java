package com.alibaba.excel.write.executor;

/**
 * Excel write Executor
 *
 * @author Jiaju Zhuang
 */
public interface ExcelWriteExecutor {
}
