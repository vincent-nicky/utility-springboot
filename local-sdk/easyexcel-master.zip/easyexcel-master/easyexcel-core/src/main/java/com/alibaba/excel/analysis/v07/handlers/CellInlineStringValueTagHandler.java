package com.alibaba.excel.analysis.v07.handlers;

/**
 * Cell inline string value handler
 *
 * @author jipengfei
 */
public class CellInlineStringValueTagHandler extends AbstractCellValueTagHandler {

}
