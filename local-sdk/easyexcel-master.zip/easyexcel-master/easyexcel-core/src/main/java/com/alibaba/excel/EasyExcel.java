package com.alibaba.excel;

/**
 * This is actually {@link EasyExcelFactory}, and short names look better.
 *
 * @author jipengfei
 */
public class EasyExcel extends EasyExcelFactory {}
