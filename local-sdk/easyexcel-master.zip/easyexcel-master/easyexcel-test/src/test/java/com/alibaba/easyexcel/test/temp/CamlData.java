package com.alibaba.easyexcel.test.temp;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * TODO
 *
 * @author 是仪
 */
@Getter
@Setter
@EqualsAndHashCode
public class CamlData {
    private String string1;
    private String String2;
    private String sTring3;
    private String STring4;
    private String STRING5;
    private String STRing6;
}
