package com.alibaba.excel.support;

/**
 * empty
 *
 * @author Jiaju Zhuang
 */
public class Empty {
}
